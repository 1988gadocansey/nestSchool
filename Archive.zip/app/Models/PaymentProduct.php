<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentProduct extends Model
{
    //
  protected $table="payment_product";

  protected $guarded=array('id');

   // public function college_name() {
   //      return $this->hasOne('App\Models\College', "ccode","college");
   //  }


}

