<?php $__env->startSection('content'); ?>
<?php $help = app('App\Http\Controllers\SystemController'); ?>
<div align="" style="margin-left: 12px">
<style>
    td{
        font-size: 13px
    }
   
        </style>
    <div class="md-card">
  
        <div   class="uk-grid" data-uk-grid-margin>

                <body>
                <div id="print">

                    <table  border="0" cellspacing="0" align="center">
                        <tr></tr>
                        <tr>
                            <th height="341" valign="top" class="bod" scope="row"><table border="0" width="100%" border="0">
                            <tr>
                                <th align="center" valign="middle" scope="row"><table border="0" width="882" height="113" border="0">
                                <tr>
                                    <th align="center" valign="middle" scope="row"><table  border="0"style="" width="882" height="113" border="0" align="left">
                                    <tr>
                                        <td><img src='<?php echo e(url("public/assets/img/printout.png")); ?>' style="width:581px;height:153px;margin-left: -5%;" /> </td

                                    </tr>
                                </table>
                                 
                                </tr>


                            </table>
                            <p>DEPARTMENT: <?php echo e(strtoupper($help->getDepartmentName($help->getProgramDepartment($student->PROGRAMMECODE)))); ?></p>
                             <p>SCHOOL: <?php echo e(strtoupper($help->getSchoolName($help->getSchoolCode($help->getProgramDepartment($student->PROGRAMMECODE))))); ?></p>
                            <h5 class="heading_c uk-margin-bottom">FEE PAYMENT TRANSACTIONS</h5>
                            <hr>
                            <div align="center">

                                <table border='0' class="uk-table" align="center"  width='900px'>
                                    <tr>
                                        <td width="" style="width:69%">
                                            <div class="table-responsive" style="margin-left:15.5%">
                                                <table border='0' class="uk-table uk-table-nowrap uk-table-no-border" width=""  style="margin-left:-1%" >
                                                    <tbody><tr>
                                                            <td style="">NAME</td> <td style="padding-right: 36px;"><?php echo e(strtoupper($student->NAME)); ?></td>
                                                        </tr>
                                                        
                                                        <tr>
                                                            
                                                                <td style="padding-right: px;">INDEX NO</td> <td style="padding-right: 93px;"><?php echo e($student->INDEXNO); ?></td>
                                                            
                                                           
                                                            
                                                        </tr>

                                                        <tr>
                                                            <td>LEVEL</td> <td style="padding-right: 203px;"><?php echo e($student->LEVEL); ?></td>
                                                        </tr>
                                                       

                                                        <tr>
                                                            <td>PROGRAMME</td> <td style="padding-right: 177px;"> <?php echo e(strtoupper($student->program->PROGRAMME)); ?></td>
                                                        </tr>



                                                    </tbody></table> </div>
                                        </td>
                
                                        <td width="237" align="left" valign="top"><table class="uk-table" width="237" border="0"  style="margin-left:-13%;">
                                                <tr>
                                                    <td width="202" border='0' ><div style="float:right;"><img style="width:130px;height:auto"  class=" " style=" margin-left: 26%" <?php echo $help->picture('<?php echo e(url("public/albums/students/$student->INDEXNO")); ?>',210); ?> src='<?php echo e(url("public/albums/students/$student->INDEXNO".'.jpg')); ?>' alt=" Picture of Student Here" /></div>
                                                       
                                                </tr>
                                            </table></td>
                                    </tr>
                                    </tr>
                                </table> <!-- end basic infos -->


                                <table class="uk-table uk-table-nowrap uk-table-hover" id=""> 
                                    <thead>
                                       <tr  class="uk-text-upper">
                                          <th>NO</th>
                                          <th>DATE</th>
                                        

                                          <th>DESCRIPTION</th>
                                          
                                          <th>DEBIT</th>
                                          <th>CREDIT</th>
                                          <th>BALANCE</th>

                                          <th>TYPE</th> 
              
                  
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr class="uk-table-middle">
                                            <td>#</td>
                                            <td><?php echo e($year); ?>/<?php echo e($sem); ?></td>
                                            <td>Balance b/d to <?php echo e($year); ?>/<?php echo e($sem); ?> academic year </td>
                                              <?php if($student->BILL_OWING>0): ?>
                                                   
                                            <td><?php echo e($student->BILL_OWING); ?></td>
                                            <?php else: ?>
                                            <td>0</td>
                                            <?php endif; ?>
                                             <?php if($student->BILL_OWING<=0): ?>
                                                   
                                            <td><?php echo e($student->BILL_OWING); ?></td>
                                            <?php else: ?>
                                            <td>0</td>
                                            <?php endif; ?>
                                            <td><?php echo e($student->BILL_OWING); ?></td>
                                            <td>
                                                <?php if($student->BILL_OWING<=0): ?>
                                                    Credit
                                                <?php else: ?>
                                                    Debit
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr class="uk-table-middle">
                                            <td>#</td>
                                            <td><?php echo e($year); ?>/<?php echo e($sem); ?></td>
                                            <td> <?php echo e($year); ?>/<?php echo e($sem); ?> academic year fees </td>
                                              <?php if($student->BILLS>0): ?>
                                                   
                                            <td><?php echo e($student->BILLS); ?></td>
                                            <?php else: ?>
                                            <td>0</td>
                                            <?php endif; ?>
                                             <?php if($student->BILLS<=0): ?>
                                                   
                                            <td><?php echo e($student->BILLS); ?></td>
                                            <?php else: ?>
                                            <td>0</td>
                                            <?php endif; ?>
                                            <td><?php echo e($student->BILLS); ?></td>
                                            <td>
                                                <?php if($student->BILLS<=0): ?>
                                                    Credit
                                                <?php else: ?>
                                                    Debit
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <?php $balance=$student->BILL_OWING+$student->BILLS; ?>
                                         <?php foreach($data as $index=> $row): ?> 
                                         
                                         
                                            <tr class="uk-table-middle">
                                                <td> <?php echo e($data->perPage()*($data->currentPage()-1)+($index+1)); ?> </td>

                                                <td> <?php echo e(@date('d/m/Y',strtotime($row->TRANSDATE))); ?></td>

                                                <td> <?php echo e(@$row->PAYMENTTYPE); ?> of <?php echo e($row->FEE_TYPE); ?> with Receipt No. <?php echo e(@$row->RECEIPTNO); ?></td>
                                                <td></td>
                                                <td> <?php echo e($help->formatMoney(@$row->AMOUNT)); ?></td>
                                                <td><?php $balance-=$row->AMOUNT ?> <?php echo e($balance); ?></td>
                                                <td>Credit</td>
                                                

                                            </tr>
                                         <?php endforeach; ?>

                                    </tbody>

                                </table>
                                 
                                 
                                
                                 
                               
                            </div>
                              
</div>
                            </tr>
                        </table></th>
                        </tr>
                        <tr></tr>
                    </table>
                    
                    <div>
                    </div>
                </div>

        </div>

</div>
</div>
        <?php $__env->stopSection(); ?>

        <?php $__env->startSection('js'); ?>
        <script type="text/javascript">

         window.print();
 

        </script>

        <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.printlayout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>