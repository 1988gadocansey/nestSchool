<?php

return array(


    'pdf' => array(
        'enabled' => true,
        'binary'  => 'D:\xampp7\htdocs\srms-laravel\public\pdf',
        'timeout' => false,
        'options' => array(),
        'env'     => array(),
    ),
    'image' => array(
        'enabled' => true,
        'binary'  => 'D:\xampp7\htdocs\srms-laravel\public\pdf',
        'timeout' => false,
        'options' => array(),
        'env'     => array(),
    ),


);
